#!/bin/bash

python demo_app.py --nextgpt_ckpt_path ./ckpt/delta_ckpt/nextgpt/7b_tiva_v0
