# The MIT License (MIT)
# Copyright © 2023 Yuma Rao
# TODO(developer): Set your name
# Copyright © 2023 <your name>

# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
# documentation files (the “Software”), to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all copies or substantial portions of
# the Software.

# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
# THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

import typing
import bittensor as bt

# TODO(developer): Rewrite with your protocol definition.

# This is the protocol for the dummy miner and validator.
# It is a simple request-response protocol where the validator sends a request
# to the miner, and the miner responds with a dummy response.

# ---- miner ----
# Example usage:
#   def dummy( synapse: Dummy ) -> Dummy:
#       synapse.dummy_output = synapse.dummy_input + 1
#       return synapse
#   axon = bt.axon().attach( dummy ).serve(netuid=...).start()

# ---- validator ---
# Example usage:
#   dendrite = bt.dendrite()
#   dummy_output = dendrite.query( Dummy( dummy_input = 1 ) )
#   assert dummy_output == 2


class DistributedTraining(bt.Synapse):
    """
    A Data parallelization distributed training protocol representation which uses bt.Synapse as its base.
    This protocol helps in training data parallelization request and response communication between
    the miner and the validator.

    Attributes:
    - train_batch: A training batch which is the embeddings of training data representing the input request sent by the validator.
    - gradients: Gradients which is calculated by the miner.
    """

    # Required request input, filled by sending dendrite caller.
    train_batch: typing.Dict
    train_emb_batch: typing.List[bt.Tensor]

    # Optional request output, filled by recieving axon.
    gradients: typing.Optional[typing.List[bt.Tensor]] = None

    def deserialize(self) -> typing.Optional[typing.List[bt.Tensor]]:
        """
        Deserialize the miner output. This method retrieves the response from
        the miner in the form of bittensor.Tensor, deserializes it and returns it
        as the output of the dendrite.query() call.

        Returns:
        - int: The deserialized response, which in this case is the value of gradients.

        # TODO: Remove it
        Example:
        Assuming a Dummy instance has a dummy_output value of 5:
        >>> dummy_instance = Dummy(dummy_input=4)
        >>> dummy_instance.dummy_output = 5
        >>> dummy_instance.deserialize()
        5
        """
        return self.gradients

class UpdateModel(bt.Synapse):
    """
    A update model protocol that propagates averaged gradients to miners which uses bt.Synapse as its base.
    This protocol helps in updating the models on miners using averaged gradients.

    Attributes:
    - train_batch: A training batch which is the embeddings of training data representing the input request sent by the validator.
    - gradients: Gradients which is calculated by the miner.
    """

    # Required request input, filled by sending dendrite caller.
    avg_gradients: typing.List[bt.Tensor]
    updated: typing.Optional[bool] = False

    def deserialize(self) -> bool:
        """
        Deserialize the miner output. This method retrieves the response from
        the miner in the form of bittensor.Tensor, deserializes it and returns it
        as the output of the dendrite.query() call.

        Returns:
        - bool: The status of whether model is updated successfully or not.

        """
        return self.updated
